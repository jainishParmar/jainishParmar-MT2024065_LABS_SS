#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main(int argc, char *argv[]){
    char* s=argv[1];
    printf("\nhello from temp.c\n");
    printf("%s\n",s);
    return 0;
}